import React from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import './styles/LandingPage.css';

const LandingPage = () => {
  const navigate = useNavigate(); // Initialize the navigate function

  return (
    <div className="landing-container">
      <h1>Welcome to Social Media Task</h1>
      <div className="login-options">
        {/* User Login Card */}
        <div className="card user-card">
          <h2>User Login</h2>
          <p>Login to submit your social media information</p>
          <button
            className="btn"
            onClick={() => navigate('/user-login')} // Navigate to user login page
          >
            Login as User
          </button>
        </div>

        {/* Admin Login Card */}
        <div className="card admin-card">
          <h2>Admin Login</h2>
          <p>Login to manage user submissions</p>
          <button
            className="btn"
            onClick={() => navigate('/dashboard')} // Navigate to admin login page
          >
            Login as Admin
          </button>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
