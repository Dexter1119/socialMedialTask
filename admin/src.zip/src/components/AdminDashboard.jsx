import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UserTable = () => {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [showModal, setShowModal] = useState(false);

  // Fetch all users on component mount
  useEffect(() => {
    axios
      .get('http://localhost:5000/api/users/submissions') // Replace with your API endpoint
      .then((response) => {
        setUsers(response.data);
      })
      .catch((error) => {
        console.error('Error fetching users:', error);
      });
  }, []);

  // Open modal and set selected user
  const handleViewProfile = (user) => {
    setSelectedUser(user);
    setShowModal(true);
  };

  // Close modal
  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedUser(null);
  };

  return (
    <div>
      <h1>User Submissions</h1>
      <table border="1" style={{ width: '100%', textAlign: 'left' }}>
        <thead>
          <tr>
            <th>Name</th>
            <th>Social Media Handle</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user._id}>
              <td>{user.name}</td>
              <td>{user.socialMediaHandle}</td>
              <td>
                <button onClick={() => handleViewProfile(user)}>View Profile</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Modal for viewing user profile */}
      {showModal && selectedUser && (
        <div style={modalStyles.overlay}>
          <div style={modalStyles.content}>
            <h2>{selectedUser.name}</h2>
            <p>Social Media Handle: {selectedUser.socialMediaHandle}</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
              {selectedUser.images.map((image, index) => (
                <img
                  key={index}
                  src={`http://localhost:5000/${image}`}
                  alt={`User Image ${index + 1}`}
                  style={{ width: '150px', height: '150px', objectFit: 'cover' }}
                />
              ))}
            </div>
            <button onClick={handleCloseModal} style={{ marginTop: '20px' }}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// Modal styles
const modalStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    width: '80%',
    maxWidth: '600px',
    textAlign: 'center',
  },
};

export default UserTable;
