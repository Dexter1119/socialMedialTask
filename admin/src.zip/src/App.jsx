import React from "react";
import { BrowserRouter as Router, Route, Routes, Navigate, Link } from "react-router-dom";
import AdminLoginForm from "./components/AdminLoginForm";
import Dashboard from "./components/AdminDashboard";
import LandingPage from "./components/LandingPage";

const App = () => {
  const isLoggedIn = false; // Static login state for demonstration

  return (
    <Router>
      
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<AdminLoginForm />} />
        <Route path="/dashboard" element={ <Dashboard />} />
        <Route path="*" element={<Navigate to="/" />} />
        <Route path="/logout" element={<LandingPage />} />
      </Routes>
    </Router>
  );
};

export default App;
